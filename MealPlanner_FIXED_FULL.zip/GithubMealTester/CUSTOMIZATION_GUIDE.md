# Quick Customization Guide

## 🎨 Common Customizations

### 1. Change Tab URLs (Most Important!)

**File:** `app/src/main/java/com/example/githubmealtester/ViewPagerAdapter.java`

```java
@NonNull
@Override
public Fragment createFragment(int position) {
    switch (position) {
        case 0: // Home
            return WebViewFragment.newInstance(BASE_URL);
        case 1: // Meals - Update this URL!
            return WebViewFragment.newInstance(BASE_URL + "#meals");
        case 2: // Recipes - Update this URL!
            return WebViewFragment.newInstance(BASE_URL + "#recipes");
        case 3: // Settings - Update this URL!
            return WebViewFragment.newInstance(BASE_URL + "#settings");
        default:
            return WebViewFragment.newInstance(BASE_URL);
    }
}
```

**Examples of different URL patterns:**
- Hash navigation: `BASE_URL + "#section"`
- Query parameters: `BASE_URL + "?page=meals"`
- Path-based: `BASE_URL + "meals"`
- Full URLs: `"https://otherdomain.com/page"`

---

### 2. Change Number of Tabs

#### To add a 5th tab:

**Step 1:** Update `ViewPagerAdapter.java`
```java
@Override
public int getItemCount() {
    return 5; // Changed from 4 to 5
}

// Add case 4 in createFragment()
case 4: // New Tab
    return WebViewFragment.newInstance(BASE_URL + "#newtab");
```

**Step 2:** Update `bottom_navigation_menu.xml`
```xml
<item
    android:id="@+id/nav_newtab"
    android:icon="@android:drawable/ic_menu_info_details"
    android:title="New Tab" />
```

**Step 3:** Update `MainActivity.java`
```java
// In onPageSelected()
case 4:
    bottomNavigationView.setSelectedItemId(R.id.nav_newtab);
    break;

// In onNavigationItemSelected()
else if (itemId == R.id.nav_newtab) {
    viewPager.setCurrentItem(4, false);
    return true;
}
```

#### To have only 3 tabs:

**Step 1:** Update `ViewPagerAdapter.java`
```java
@Override
public int getItemCount() {
    return 3; // Changed from 4 to 3
}

// Remove case 3 from createFragment()
```

**Step 2:** Remove last item from `bottom_navigation_menu.xml`

**Step 3:** Remove case 3 handling from `MainActivity.java`

---

### 3. Change Tab Icons

#### Using built-in Android icons:
```xml
<!-- Common Android icons -->
android:icon="@android:drawable/ic_menu_compass"      <!-- Compass -->
android:icon="@android:drawable/ic_menu_today"        <!-- Calendar -->
android:icon="@android:drawable/ic_menu_edit"         <!-- Edit -->
android:icon="@android:drawable/ic_menu_preferences"  <!-- Settings -->
android:icon="@android:drawable/ic_menu_info_details" <!-- Info -->
android:icon="@android:drawable/ic_menu_search"       <!-- Search -->
android:icon="@android:drawable/ic_menu_add"          <!-- Add -->
android:icon="@android:drawable/ic_menu_view"         <!-- View -->
```

#### Using custom icons:
1. Add your icon files to `app/src/main/res/drawable/`
2. Reference them in the menu:
```xml
android:icon="@drawable/ic_custom_home"
```

---

### 4. Color Schemes

#### Dark Theme (Current):
```xml
<color name="background">#FF121212</color>
<color name="navigation_background">#FF1E1E1E</color>
<color name="nav_selected">#FF2196F3</color>
<color name="nav_unselected">#FF9E9E9E</color>
```

#### Light Theme:
```xml
<color name="background">#FFFAFAFA</color>
<color name="navigation_background">#FFFFFFFF</color>
<color name="nav_selected">#FF1976D2</color>
<color name="nav_unselected">#FF757575</color>
```

#### Material You / Custom Accent:
```xml
<color name="background">#FFFFFFFF</color>
<color name="navigation_background">#FFF5F5F5</color>
<color name="nav_selected">#FF6200EE</color>      <!-- Purple -->
<color name="nav_unselected">#FFB0B0B0</color>
```

#### Green Theme:
```xml
<color name="background">#FFFAFAFA</color>
<color name="navigation_background">#FFFFFFFF</color>
<color name="nav_selected">#FF4CAF50</color>      <!-- Green -->
<color name="nav_unselected">#FF9E9E9E</color>
```

---

### 5. Tab Names

**File:** `app/src/main/res/values/strings.xml`

```xml
<resources>
    <string name="app_name">Your App Name</string>
    <string name="nav_home">Home</string>
    <string name="nav_meals">Meals</string>
    <string name="nav_recipes">Recipes</string>
    <string name="nav_settings">Settings</string>
</resources>
```

Then reference in `bottom_navigation_menu.xml`:
```xml
android:title="@string/nav_home"
```

---

### 6. Website URL

**File:** `ViewPagerAdapter.java`

```java
private static final String BASE_URL = "https://githubmealtester.netlify.app/";
```

Change to your website:
```java
private static final String BASE_URL = "https://yourdomain.com/";
```

---

### 7. Enable/Disable Features

#### Enable Swipe Between Tabs:
**File:** `MainActivity.java`
```java
viewPager.setUserInputEnabled(true); // Change from false
```

#### Enable Tab Switching Animation:
**File:** `MainActivity.java`
```java
// Change all setCurrentItem() calls:
viewPager.setCurrentItem(0, true); // Change false to true
```

#### Customize Pull-to-Refresh Color:
**File:** `WebViewFragment.java` in `onCreateView()`
```java
swipeRefreshLayout.setColorSchemeResources(
    R.color.nav_selected,
    R.color.teal_200,
    R.color.purple_500
);
```

---

### 8. Bottom Navigation Style

#### Always Show Labels:
```xml
app:labelVisibilityMode="labeled"
```

#### Show Only Selected:
```xml
app:labelVisibilityMode="selected"
```

#### Auto Hide/Show:
```xml
app:labelVisibilityMode="auto"
```

#### Never Show:
```xml
app:labelVisibilityMode="unlabeled"
```

---

## 📱 Testing Your Changes

After making changes:

1. **Sync Gradle** - File > Sync Project with Gradle Files
2. **Clean Build** - Build > Clean Project
3. **Rebuild** - Build > Rebuild Project
4. **Run** - Click the green play button

---

## 🎯 Common URL Patterns for Your Website

Depending on your website structure, use one of these patterns:

```java
// Hash-based routing (Single Page Apps)
case 0: return WebViewFragment.newInstance(BASE_URL + "#/home");
case 1: return WebViewFragment.newInstance(BASE_URL + "#/meals");

// Path-based routing
case 0: return WebViewFragment.newInstance(BASE_URL + "home");
case 1: return WebViewFragment.newInstance(BASE_URL + "meals");

// Query parameter routing
case 0: return WebViewFragment.newInstance(BASE_URL + "?page=home");
case 1: return WebViewFragment.newInstance(BASE_URL + "?page=meals");

// Subdomain routing
case 0: return WebViewFragment.newInstance("https://app.yourdomain.com/");
case 1: return WebViewFragment.newInstance("https://meals.yourdomain.com/");

// Mixed - Different domains per tab
case 0: return WebViewFragment.newInstance("https://site1.com/");
case 1: return WebViewFragment.newInstance("https://site2.com/");
```

---

## 🚀 Quick Start Checklist

- [ ] Update `BASE_URL` in ViewPagerAdapter.java
- [ ] Update tab URLs in ViewPagerAdapter.java
- [ ] Change tab names in strings.xml
- [ ] Update tab icons in bottom_navigation_menu.xml
- [ ] Choose color scheme in colors.xml
- [ ] Change app name in strings.xml
- [ ] Test on emulator or device
- [ ] Build release APK when ready

---

## 💡 Pro Tips

1. **Use your website's actual navigation structure** - Don't guess the URLs
2. **Test each tab** - Make sure URLs load correctly
3. **Match your brand colors** - Use your website's color palette
4. **Use descriptive tab names** - Keep them short but clear
5. **Test back button behavior** - Ensure it works as expected
6. **Consider offline support** - WebView caches content automatically
7. **Custom icons look better** - Consider creating custom SVG icons

---

## 🎨 Icon Resources

Free icon sources:
- Material Icons: https://fonts.google.com/icons
- Iconify: https://icon-sets.iconify.design/
- Flaticon: https://www.flaticon.com/

Convert to Android format using Android Studio's Vector Asset tool.
