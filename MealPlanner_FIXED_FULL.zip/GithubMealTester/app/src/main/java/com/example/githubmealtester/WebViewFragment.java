package com.example.githubmealtester;

import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class WebViewFragment extends Fragment {

    private static final String ARG_URL = "url";
    private static final String ARG_SECTION = "section";

    public static WebViewFragment newInstance(String url, String section) {
        WebViewFragment fragment = new WebViewFragment();
        Bundle args = new Bundle();
        args.putString(ARG_URL, url);
        args.putString(ARG_SECTION, section);
        fragment.setArguments(args);
        return fragment;
    }

    private WebView webView;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_webview, container, false);

        webView = view.findViewById(R.id.webView);

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setDatabaseEnabled(true);
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);

                String section = (getArguments() != null)
                        ? getArguments().getString(ARG_SECTION, "plan")
                        : "plan";

                applyAppMode(section);
            }
        });

        if (getArguments() != null) {
            String url = getArguments().getString(ARG_URL, "https://githubmealtester.netlify.app/");
            webView.loadUrl(url);
        }

        return view;
    }

    private void applyAppMode(String section) {
        String js = ("""
        (function(){
          try {
            const keep = "%s";

            // 1) Hide the web app's own header/nav (native app has tabs already)
            const hideAll = (sel) => {
              try { document.querySelectorAll(sel).forEach(e => { e.style.display = "none"; }); } catch(e) {}
            };
            hideAll("header");
            hideAll("nav");

            // Also hide any top "button bar" that looks like the web's tabs (Plan/Shopping/Recipes/Admin)
            try {
              const maybeBars = Array.from(document.querySelectorAll("div,section"))
                .slice(0, 40)
                .filter(el => {
                  const t = (el.textContent || "").replace(/\s+/g," ").trim();
                  return t.includes("Plan") && t.includes("Shopping") && t.includes("Recipes") && t.includes("Admin");
                });
              maybeBars.forEach(el => el.style.display = "none");
            } catch(e) {}

            // 2) Section isolation: keep only the relevant section visible.
            function findContainerByHeadingText(exactText) {
              const hs = Array.from(document.querySelectorAll("h1,h2,h3,h4"));
              const hit = hs.find(h => (h.textContent || "").trim() === exactText);
              if (!hit) return null;
              return hit.closest("section") || hit.closest("div") || hit.parentElement;
            }

            const roots = {
              shopping: findContainerByHeadingText("Shopping List"),
              recipes: findContainerByHeadingText("Recipes"),
              admin: findContainerByHeadingText("Admin"),
              plan: null
            };

            // Plan headings vary: "7-Day Plan", "14-Day Plan", "30-Day Plan", etc.
            try {
              const planHead = Array.from(document.querySelectorAll("h1,h2,h3")).find(h => {
                const t = (h.textContent || "").trim();
                return /\bPlan\b/i.test(t) && (/-Day/i.test(t) || t === "Plan" || /Meal\s*Planner/i.test(t));
              });
              if (planHead) roots.plan = planHead.closest("section") || planHead.closest("div") || planHead.parentElement;
            } catch(e) {}

            const sections = ["plan","shopping","recipes","admin"];
            sections.forEach(s => {
              if (s === keep) return;
              const r = roots[s];
              if (r) r.style.display = "none";
            });

            // 3) Unlock fallback: clear lock-like localStorage keys if unlock click doesn't work
            function patchUnlockFallback(){
              const btns = Array.from(document.querySelectorAll("button"));
              const unlockBtn = btns.find(b => /unlock\s*plan/i.test((b.textContent || "").trim()));
              if (!unlockBtn || unlockBtn.__mp_unlock_patched) return;
              unlockBtn.__mp_unlock_patched = true;

              unlockBtn.addEventListener("click", function(){
                setTimeout(() => {
                  const locked = Array.from(document.querySelectorAll("*"))
                    .some(el => (el.textContent || "").includes("Plan is locked"));
                  if (!locked) return;

                  try {
                    const keys = [];
                    for (let i = 0; i < localStorage.length; i++) keys.push(localStorage.key(i));
                    keys.filter(k => /lock|locked/i.test(k)).forEach(k => {
                      try { localStorage.removeItem(k); } catch(e) {}
                      try { localStorage.setItem(k, "false"); } catch(e) {}
                    });
                  } catch(e) {}

                  try { location.reload(); } catch(e) {}
                }, 250);
              }, { passive: true });
            }
            patchUnlockFallback();

            // 4) Shop Mode: when an item is checked, hide it and offer a 3s undo (Shopping tab only)
            function patchShopModeHideWithUndo(){
              const undoId = "__mp_undo";
              if (document.getElementById(undoId)) return;

              function ensureBar(){
                let bar = document.getElementById(undoId);
                if (bar) return bar;

                bar = document.createElement("div");
                bar.id = undoId;
                bar.style.position = "fixed";
                bar.style.left = "12px";
                bar.style.right = "12px";
                bar.style.bottom = "16px";
                bar.style.zIndex = "2147483647";
                bar.style.padding = "12px 14px";
                bar.style.borderRadius = "12px";
                bar.style.background = "rgba(20,20,20,0.92)";
                bar.style.color = "#fff";
                bar.style.display = "none";
                bar.style.fontSize = "14px";
                bar.style.backdropFilter = "blur(10px)";
                bar.style.webkitBackdropFilter = "blur(10px)";
                bar.innerHTML = '<span id="__mp_undo_text"></span><button id="__mp_undo_btn" style="float:right;background:transparent;border:0;color:#7CFFDE;font-weight:600;">UNDO</button>';

                document.body.appendChild(bar);
                return bar;
              }

              function showUndo(text, undoFn){
                const bar = ensureBar();
                bar.querySelector("#__mp_undo_text").textContent = text;

                const btn = bar.querySelector("#__mp_undo_btn");
                btn.onclick = () => {
                  bar.style.display = "none";
                  try { undoFn && undoFn(); } catch(e) {}
                };

                bar.style.display = "block";
                setTimeout(() => { bar.style.display = "none"; }, 3000);
              }

              function handleChecked(input){
                const row = input.closest("li") || input.closest("div") || input.parentElement;
                if (!row) return;

                const prevDisplay = row.style.display;
                setTimeout(() => {
                  if (input.checked) {
                    row.style.display = "none";
                    showUndo("Item removed", () => {
                      row.style.display = prevDisplay || "";
                      input.checked = false;
                      try { input.dispatchEvent(new Event("change", { bubbles: true })); } catch(e) {}
                    });
                  }
                }, 200);
              }

              function bind(){
                const inputs = Array.from(document.querySelectorAll('input[type="checkbox"]'));
                inputs.forEach(inp => {
                  if (inp.__mp_bound) return;
                  inp.__mp_bound = true;
                  inp.addEventListener("change", () => handleChecked(inp));
                });
              }

              bind();
              const mo = new MutationObserver(() => bind());
              mo.observe(document.body, { subtree: true, childList: true });
            }

            if (keep === "shopping") {
              patchShopModeHideWithUndo();
            }
          } catch(e) {}
        })();
        """).formatted(section);

        injectJavaScript(js);
    }

    private void injectJavaScript(String js) {
        if (webView == null) return;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            webView.evaluateJavascript(js, null);
        } else {
            webView.loadUrl("javascript:" + js);
        }
    }
}
