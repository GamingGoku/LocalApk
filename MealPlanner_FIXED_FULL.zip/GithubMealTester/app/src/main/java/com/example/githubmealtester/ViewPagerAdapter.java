package com.example.githubmealtester;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class ViewPagerAdapter extends FragmentStateAdapter {

    private static final String BASE_URL = "https://githubmealtester.netlify.app/";
    
    public ViewPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        // URLs configured for the Meal Planner MVP sections
        switch (position) {
            case 0: // Plan
                return WebViewFragment.newInstance(BASE_URL, "plan");
            case 1: // Shopping
                return WebViewFragment.newInstance(BASE_URL, "shopping");
            case 2: // Recipes
                return WebViewFragment.newInstance(BASE_URL, "recipes");
            case 3: // Admin
                return WebViewFragment.newInstance(BASE_URL, "admin");
            default:
                return WebViewFragment.newInstance(BASE_URL, "plan");
        }
    }

    @Override
    public int getItemCount() {
        return 4; // Number of tabs
    }
}
