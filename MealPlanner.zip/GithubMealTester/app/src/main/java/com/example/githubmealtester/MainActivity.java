package com.example.githubmealtester;

import android.os.Bundle;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class MainActivity extends AppCompatActivity {

    private ViewPager2 viewPager;
    private BottomNavigationView bottomNavigationView;
    private ViewPagerAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewPager = findViewById(R.id.viewPager);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);

        // Setup ViewPager with adapter
        adapter = new ViewPagerAdapter(this);
        viewPager.setAdapter(adapter);
        
        // Disable swipe to prevent accidental navigation
        viewPager.setUserInputEnabled(false);

        // Link ViewPager with BottomNavigationView
        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                switch (position) {
                    case 0:
                        bottomNavigationView.setSelectedItemId(R.id.nav_home);
                        break;
                    case 1:
                        bottomNavigationView.setSelectedItemId(R.id.nav_meals);
                        break;
                    case 2:
                        bottomNavigationView.setSelectedItemId(R.id.nav_recipes);
                        break;
                    case 3:
                        bottomNavigationView.setSelectedItemId(R.id.nav_settings);
                        break;
                }
            }
        });

        // Handle bottom navigation clicks
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.nav_home) {
                    viewPager.setCurrentItem(0, false);
                    return true;
                } else if (itemId == R.id.nav_meals) {
                    viewPager.setCurrentItem(1, false);
                    return true;
                } else if (itemId == R.id.nav_recipes) {
                    viewPager.setCurrentItem(2, false);
                    return true;
                } else if (itemId == R.id.nav_settings) {
                    viewPager.setCurrentItem(3, false);
                    return true;
                }
                return false;
            }
        });
    }

    @Override
    public void onBackPressed() {
        // Get current fragment
        Fragment fragment = getSupportFragmentManager().findFragmentByTag("f" + viewPager.getCurrentItem());
        
        if (fragment instanceof WebViewFragment) {
            WebViewFragment webViewFragment = (WebViewFragment) fragment;
            if (webViewFragment.canGoBack()) {
                webViewFragment.goBack();
                return;
            }
        }
        
        super.onBackPressed();
    }
}
