package com.example.githubmealtester;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class WebViewFragment extends Fragment {

    private static final String ARG_URL = "url";
    private static final String ARG_SECTION = "section";
    private WebView webView;
    private SwipeRefreshLayout swipeRefreshLayout;
    private String url;
    private String section;

    public static WebViewFragment newInstance(String url) {
        return newInstance(url, null);
    }

    public static WebViewFragment newInstance(String url, String section) {
        WebViewFragment fragment = new WebViewFragment();
        Bundle args = new Bundle();
        args.putString(ARG_URL, url);
        args.putString(ARG_SECTION, section);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            url = getArguments().getString(ARG_URL);
            section = getArguments().getString(ARG_SECTION);
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_webview, container, false);
        
        swipeRefreshLayout = view.findViewById(R.id.swipeRefreshLayout);
        webView = view.findViewById(R.id.webView);

        // WebView settings
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        webSettings.setBuiltInZoomControls(false);
        webSettings.setDisplayZoomControls(false);
        webSettings.setSupportZoom(false);
        webSettings.setAllowFileAccess(true);
        webSettings.setAllowContentAccess(true);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        webSettings.setCacheMode(WebSettings.LOAD_DEFAULT);
        webSettings.setAppCacheEnabled(true);

        // WebViewClient
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                swipeRefreshLayout.setRefreshing(false);
                
                // Navigate to the correct section after page loads
                if (section != null && !section.isEmpty()) {
                    navigateToSection(section);
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
        });

        // Pull to refresh
        swipeRefreshLayout.setOnRefreshListener(() -> webView.reload());

        // Load URL
        if (url != null) {
            webView.loadUrl(url);
        }

        return view;
    }

    private void navigateToSection(String section) {
        // Click the appropriate navigation button in the web app
        String javascript = "";
        switch (section) {
            case "plan":
                javascript = "javascript:(function() { " +
                        "var btn = document.querySelector('nav button:nth-child(1)'); " +
                        "if (btn) btn.click(); " +
                        "})()";
                break;
            case "shopping":
                javascript = "javascript:(function() { " +
                        "var btn = document.querySelector('nav button:nth-child(2)'); " +
                        "if (btn) btn.click(); " +
                        "})()";
                break;
            case "recipes":
                javascript = "javascript:(function() { " +
                        "var btn = document.querySelector('nav button:nth-child(3)'); " +
                        "if (btn) btn.click(); " +
                        "})()";
                break;
            case "admin":
                javascript = "javascript:(function() { " +
                        "var btn = document.querySelector('nav button:nth-child(4)'); " +
                        "if (btn) btn.click(); " +
                        "})()";
                break;
        }
        
        if (!javascript.isEmpty()) {
            webView.loadUrl(javascript);
        }
    }

    public boolean canGoBack() {
        return webView != null && webView.canGoBack();
    }

    public void goBack() {
        if (webView != null) {
            webView.goBack();
        }
    }

    public void reload() {
        if (webView != null) {
            webView.reload();
        }
    }

    public void navigateToSectionPublic(String section) {
        this.section = section;
        if (webView != null) {
            navigateToSection(section);
        }
    }
}
