# Meal Planner - Android App with Sleek Tab Navigation

A modern Android wrapper app for the Meal Planner MVP web application with a sleek, app-like UI featuring bottom tab navigation.

## 🎨 Features

- ✨ **Modern Bottom Tab Navigation** - Sleek Material Design bottom navigation bar
- 🎯 **4 Main Sections** - Easy access to Plan, Shopping, Recipes, and Admin
- 🌙 **Dark Theme** - Modern dark color scheme (easily customizable to light)
- 📱 **App-Like Experience** - No action bar, full immersive UI
- 🔄 **Pull-to-Refresh** - Swipe down to refresh any section
- 🔙 **Smart Back Navigation** - Back button works within WebView before exiting
- 💾 **Offline Caching** - Content caching for better performance
- 🚀 **Automatic Section Navigation** - Tabs automatically navigate to the correct section
- 🍽️ **Full Meal Planning** - Access all features: meal planning, shopping lists, recipes, and admin

## 📱 Screenshots Preview

The app features:
- Clean bottom navigation bar with 4 tabs
- Full-screen WebView content
- Dark theme with blue accent colors
- Material Design components

## 🛠 Setup Instructions

### Prerequisites

1. **Android Studio** - Download from https://developer.android.com/studio
2. **Java Development Kit (JDK)** - Version 8 or higher

### Building the App

1. **Open the project in Android Studio:**
   - Launch Android Studio
   - Click "Open an Existing Project"
   - Navigate to the `GithubMealTester` folder and select it

2. **Sync Gradle:**
   - Android Studio should automatically sync Gradle files
   - If not, click "File" > "Sync Project with Gradle Files"
   - Wait for dependencies to download

3. **Build the APK:**
   - Click "Build" > "Build Bundle(s) / APK(s)" > "Build APK(s)"
   - Wait for the build to complete
   - The APK will be located in `app/build/outputs/apk/debug/app-debug.apk`

### Running on an Emulator

1. **Create an AVD (Android Virtual Device):**
   - Click "Tools" > "Device Manager"
   - Click "Create Device"
   - Select a device (e.g., Pixel 5) and click "Next"
   - Select a system image (API 24 or higher) and click "Next"
   - Click "Finish"

2. **Run the app:**
   - Click the green "Run" button (play icon)
   - Select your emulator from the list
   - The app will launch automatically

### Running on a Physical Device

1. **Enable Developer Options on your Android device:**
   - Go to Settings > About Phone
   - Tap "Build Number" 7 times
   - Go back to Settings > Developer Options
   - Enable "USB Debugging"

2. **Connect your device:**
   - Connect your Android device via USB
   - Allow USB debugging when prompted on your device

3. **Run the app:**
   - Click the green "Run" button
   - Select your device from the list
   - The app will install and launch automatically

## 🎨 Customization Guide

### Change Tab Names and Icons

Edit `app/src/main/res/menu/bottom_navigation_menu.xml`:
```xml
<item
    android:id="@+id/nav_home"
    android:icon="@android:drawable/ic_menu_compass"
    android:title="Home" />
```

For custom icons, add SVG/PNG files to the drawable folder and reference them.

### Configure Tab URLs

Edit `ViewPagerAdapter.java` to set the URL for each tab:
```java
switch (position) {
    case 0: // Home
        return WebViewFragment.newInstance(BASE_URL);
    case 1: // Meals
        return WebViewFragment.newInstance(BASE_URL + "#meals");
    // Add or modify tabs here
}
```

### Add or Remove Tabs

1. Edit `ViewPagerAdapter.java`:
   - Update `getItemCount()` to return the number of tabs
   - Add cases in `createFragment()` for new tabs

2. Edit `app/src/main/res/menu/bottom_navigation_menu.xml`:
   - Add or remove `<item>` elements

3. Edit `MainActivity.java`:
   - Add cases in both `onPageSelected()` and `onNavigationItemSelected()`

### Switch to Light Theme

Edit `app/src/main/res/values/colors.xml` and uncomment the light theme colors:
```xml
<!-- Light theme colors -->
<color name="background">#FFFAFAFA</color>
<color name="navigation_background">#FFFFFFFF</color>
<color name="nav_selected">#FF1976D2</color>
<color name="nav_unselected">#FF757575</color>
```

### Change the Main Website URL

Edit `ViewPagerAdapter.java`:
```java
private static final String BASE_URL = "https://your-website.com/";
```

### Change App Colors

Edit `app/src/main/res/values/colors.xml`:
- `nav_selected` - Color of selected tab icon/text
- `nav_unselected` - Color of unselected tabs
- `navigation_background` - Bottom navigation bar background
- `background` - Main app background

### Change the App Name

Edit `app/src/main/res/values/strings.xml`:
```xml
<string name="app_name">Your App Name</string>
```

### Change Package Name

1. Right-click on the package `com.example.githubmealtester` in the Project view
2. Select "Refactor" > "Rename"
3. Update the package name in:
   - `app/build.gradle` (applicationId)
   - `AndroidManifest.xml` (package attribute)

### Add a Custom App Icon

Use Android Studio's Image Asset tool:
1. Right-click on `res` folder
2. New > Image Asset
3. Follow the wizard to generate icons from your image
4. Icons will be placed in the appropriate mipmap folders

## 📁 Project Structure

```
GithubMealTester/
├── app/
│   ├── src/main/
│   │   ├── java/com/example/githubmealtester/
│   │   │   ├── MainActivity.java          # Main activity with navigation
│   │   │   ├── ViewPagerAdapter.java      # Manages tab fragments
│   │   │   └── WebViewFragment.java       # Individual tab content
│   │   ├── res/
│   │   │   ├── layout/
│   │   │   │   ├── activity_main.xml      # Main layout with tabs
│   │   │   │   └── fragment_webview.xml   # WebView fragment layout
│   │   │   ├── menu/
│   │   │   │   └── bottom_navigation_menu.xml  # Tab definitions
│   │   │   ├── values/
│   │   │   │   ├── colors.xml             # Color definitions
│   │   │   │   ├── strings.xml            # String resources
│   │   │   │   └── themes.xml             # App theme
│   │   │   └── color/
│   │   │       └── bottom_nav_color.xml   # Navigation color states
│   │   └── AndroidManifest.xml
│   ├── build.gradle                       # App-level dependencies
│   └── proguard-rules.pro
├── build.gradle                           # Project-level config
├── settings.gradle                        # Project settings
└── gradle.properties                      # Gradle properties
```

## 🔧 Advanced Customization

### Enable Swipe Between Tabs

In `MainActivity.java`, change:
```java
viewPager.setUserInputEnabled(true);  // Enable swipe
```

### Add Smooth Transitions Between Tabs

In `MainActivity.java`, change the `setCurrentItem()` calls:
```java
viewPager.setCurrentItem(0, true);  // true = smooth animation
```

### Customize Pull-to-Refresh Colors

In `WebViewFragment.java`, add:
```java
swipeRefreshLayout.setColorSchemeResources(
    R.color.nav_selected,
    R.color.teal_200
);
```

## 📋 Requirements

- **Minimum SDK:** 24 (Android 7.0)
- **Target SDK:** 34 (Android 14)
- **Compile SDK:** 34
- **Required Permissions:** Internet, Network State

## 🐛 Troubleshooting

**App crashes on startup:**
- Verify internet connectivity
- Check that the URL is correct and accessible
- Check logcat for specific error messages

**Tabs not switching:**
- Ensure IDs in menu match the cases in MainActivity
- Verify ViewPagerAdapter.getItemCount() matches number of tabs

**WebView not loading:**
- Check INTERNET permission in AndroidManifest.xml
- Verify usesCleartextTraffic is true if using HTTP
- Check the website URL is accessible

**Back button not working:**
- The back button navigates WebView history first
- Press back again when at the start of history to exit

**Build errors:**
- Sync Gradle files (File > Sync Project with Gradle Files)
- Clean and rebuild (Build > Clean Project, then Build > Rebuild Project)
- Try "File" > "Invalidate Caches / Restart"

## 🎯 Usage Tips

1. **Customize for your website structure** - Update the URLs in ViewPagerAdapter to match your site's navigation
2. **Use meaningful tab names** - Update strings.xml with descriptive names
3. **Match your website's branding** - Customize colors to match your site
4. **Test on multiple devices** - Ensure responsiveness across different screen sizes
5. **Consider adding more features** - File upload, notifications, deep linking, etc.

## 📝 License

This is a customizable template. Modify as needed for your specific use case.

## 🆘 Support

For issues with:
- **Android Studio:** https://developer.android.com/studio/intro
- **Material Design:** https://material.io/develop/android
- **WebView:** https://developer.android.com/reference/android/webkit/WebView
